package com.farmacia.prototipo.view;

public class PrototipoFarmacia {
 public static void main(String[] args) {
        
        int huevo = 1;
        System.out.println("hola esta es la tienda" + huevo );
    }
}
